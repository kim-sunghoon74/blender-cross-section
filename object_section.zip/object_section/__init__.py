# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Cross Section",
    "author": "Rajeev Nair",
    "version": (0, 3),
    "blender": (2, 80, 0),
    "location": "Viewport-> Object Menu -> Cross Section",
    "description": "Create cross-section on selected objects.",
    "warning": "",
    "doc_url": "https://www.digital-sculptors.com/cms/index.php/software/blender-plugins.html",
    "category": "Object",
}

import bpy, bmesh
from mathutils import Vector
from math import floor
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
)

def newobj(bm, axis):
    me = bpy.data.meshes.new(axis)
    bm.to_mesh(me)
    ob = bpy.data.objects.new(axis, me)
    bpy.data.collections[axis].objects.link(ob)    
    bm.clear()
    bm.free()

def convert_to_curves(axis):
    is_col = False;
    for c in bpy.data.collections:
        if c.name == axis:
            is_col = True
            break
    if not is_col:
        return
    bpy.ops.object.select_all(action='DESELECT')
    objs = []
    for o in bpy.data.collections[axis].objects:
        if o.type == 'MESH':
            objs.append(o)
    obj_count = len(objs)
    if obj_count == 0: 
        return
    bpy.context.view_layer.objects.active =  objs[0]            
    for obj in objs:
        obj.select_set(True)
    bpy.ops.object.convert(target='CURVE')
    bpy.ops.object.select_all(action='DESELECT')

def BBox(obj):
    mat = obj.matrix_world
    bb = obj.bound_box
    min_x = bb[0][0]
    min_y = bb[0][1]
    min_z = bb[0][2]
    max_x = bb[6][0]
    max_y = bb[6][1]
    max_z = bb[6][2]
    min_v = mat @ Vector((min_x, min_y, min_z))
    max_v = mat @ Vector((max_x, max_y, max_z))
    return min_v.x , min_v.y, min_v.z, max_v.x, max_v.y, max_v.z

def create_section(context, axis, interval):
    objs = []
    for o in context.selected_editable_objects:
        if o.type == 'MESH':
            objs.append(o)
    if len(objs) == 0:
        return
    #check if collection name exits
    IsColExists = False
    for col in bpy.data.collections:
        if col.name == axis:
            IsColExists = True
    if IsColExists == False:
        collect_sec = bpy.data.collections.new(axis)
        context.scene.collection.children.link(collect_sec)
    for ob in objs:
        bmo = bmesh.new()        
        #Apply modifiers.
        dpgrph = context.evaluated_depsgraph_get()
        mtrx = ob.matrix_world.copy()
        ob_copy = ob.evaluated_get(dpgrph)
        try:
            me = ob_copy.to_mesh()
        except RuntimeError:
            me = None
        if me is None:
            continue
        if len(me.polygons) == 0:
            continue
        bmo.from_mesh(me)
        bmo.transform(mtrx)            
        min_x, min_y, min_z, max_x, max_y, max_z = BBox(ob)            
        planes = []
        pl_no=(0,0,1)
        if axis == "Z_section":
            min_range = floor(min_z/interval) - 2
            max_range = floor(max_z/interval) + 2
            planes = [Vector((0, 0, i * interval)) for i in range(min_range, max_range, 1)]
            pl_no = (0,0,1)
        elif axis == "Y_section":
            min_range = floor(min_y/interval) - 2
            max_range = floor(max_y/interval) + 2
            planes = [Vector((0, i * interval, 0)) for i in range(min_range, max_range, 1)]
            pl_no = (0,1,0)
        elif axis == "X_section":
            min_range = floor(min_x/interval) - 2
            max_range = floor(max_x/interval) + 2
            planes = [Vector((i * interval, 0, 0)) for i in range(min_range, max_range, 1)]
            pl_no = (1,0,0)
        p0 = planes.pop(0)
        while planes:
            bm = bmo.copy()
            p1 = planes.pop(0)
            bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:],
                plane_co=p0,
                plane_no=pl_no,
                clear_inner=True,
                clear_outer=True)
            if len(bm.verts):
                newobj(bm, axis)
            p0 = p1
        
        bmo.clear()
        bmo.free()
        

def main(context, x_axis, y_axis, z_axis, interval):
    import time
    t = time.time()
    if x_axis:
        print("Please wait.. Creating  X sections")
        create_section(context, "X_section", interval * 0.001)       
    if y_axis:
        print("Please wait.. Creating  Y sections")
        create_section(context, "Y_section", interval * 0.001)
    if z_axis:
        print("Please wait.. Creating  Z sections")
        create_section(context, "Z_section", interval * 0.001)
    if x_axis:
        print("Please wait.. converting  X sections")
        convert_to_curves("X_section")
    if y_axis:
        print("Please wait.. converting  Y sections")
        convert_to_curves("Y_section")
    if z_axis:
        print("Please wait.. converting  Z sections")
        convert_to_curves("Z_section")
    # Purge Meshes from the conversion.
    for block in bpy.data.meshes:
        if block.users == 0:
            bpy.data.meshes.remove(block)
    print("Created sections in %.4f sec" % (time.time() - t))


class CrossSection(bpy.types.Operator):
    """Create Cross Section"""
    bl_idname = "object.cross_section"
    bl_label = "Create sections"
    bl_options = {'PRESET', 'UNDO'}
    bl_icon = 'PLUGIN'
    
    x_axis: BoolProperty(
        name = "X",
        description = "Create sections perpendicular to X axis",
        default = True,
    )
    
    y_axis: BoolProperty(
        name = "Y",
        description = "Create sections perpendicular to Y axis",
        default = True,
    )
    
    z_axis: BoolProperty(
        name = "Z",
        description = "Create sections perpendicular to Z axis",
        default = True,
    )
    
    interval: IntProperty(
        name = "Interval",
        description = "Section Interval",
        min = 1, max = 1000,
        default = 100,
    )

    @classmethod
    def poll(cls, context):
        if len(context.selected_editable_objects) == 0:
            return False
        else:
            return True

    def execute(self, context):
        main(context, self.x_axis, self.y_axis, self.z_axis, self.interval)
        return {'FINISHED'}
    
    def invoke(self, context, event):
        # print(self.recursion_chance_select)
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=300)
    
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column()
        col.label(text="Select Axis")
        rowsub = col.row()
        rowsub.prop(self, "x_axis")
        rowsub.prop(self, "y_axis")
        rowsub.prop(self, "z_axis")
        
        box = layout.box()
        col = box.column()
        col.label(text="Interval in MM")
        rowsub = col.row()
        rowsub.prop(self, "interval")
    

def menu_func(self, context):
    self.layout.separator()
    self.layout.operator(CrossSection.bl_idname, text=CrossSection.bl_label, icon=CrossSection.bl_icon)

def register():
    bpy.utils.register_class(CrossSection)
    bpy.types.VIEW3D_MT_object.append(menu_func)


def unregister():
    bpy.utils.unregister_class(CrossSection)
    bpy.types.VIEW3D_MT_object.remove(menu_func)


if __name__ == "__main__":
    register()

    # test call
    bpy.ops.object.cross_section()
